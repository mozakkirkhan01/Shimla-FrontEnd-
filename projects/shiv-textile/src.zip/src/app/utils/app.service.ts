import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";

@Injectable({
  providedIn: 'root'
})
export class AppService {
  public readonly baseUrl: string = "http://localhost:1113/";

  constructor(private http: HttpClient) {
    //this.baseUrl = "http://localhost:3776/";
  }

  //Enum
  getEmployeeTypeList() {
    return this.http.get(this.baseUrl + '/api/Enum/EmployeeTypeList')
  }
  getPartyTypeList() {
    return this.http.get(this.baseUrl + '/api/Enum/PartyTypeList')
  }

  //ProductStock
  getProductStockList(obj: any) {
    return this.http.post(this.baseUrl + '/api/ProductStock/ProductStockList', obj)
  }
  getProductStockDetailList(obj: any) {
    return this.http.post(this.baseUrl + '/api/ProductStock/ProductStockDetailList', obj)
  }

  //Purchase
  getPurchaseList(obj: any) {
    return this.http.post(this.baseUrl + '/api/Purchase/PurchaseList', obj)
  }
  getPurchaseDetail(obj: any) {
    return this.http.post(this.baseUrl + '/api/Purchase/PurchaseDetail', obj)
  }
  savePurchase(obj: any) {
    return this.http.post(this.baseUrl + '/api/Purchase/savePurchase', obj)
  }
  deletePurchase(obj: any) {
    return this.http.post(this.baseUrl + '/api/Purchase/deletePurchase', obj)
  }

  //Category
  getCategoryList(obj: any) {
    return this.http.post(this.baseUrl + '/api/Category/CategoryList', obj)
  }
  saveCategory(obj: any) {
    return this.http.post(this.baseUrl + '/api/Category/saveCategory', obj)
  }
  deleteCategory(obj: any) {
    return this.http.post(this.baseUrl + '/api/Category/deleteCategory', obj)
  }

  //GST
  getGSTList(obj: any) {
    return this.http.post(this.baseUrl + '/api/GST/GSTList', obj)
  }
  saveGST(obj: any) {
    return this.http.post(this.baseUrl + '/api/GST/saveGST', obj)
  }
  deleteGST(obj: any) {
    return this.http.post(this.baseUrl + '/api/GST/deleteGST', obj)
  }
  //Product
  getProductList(obj: any) {
    return this.http.post(this.baseUrl + '/api/Product/ProductList', obj)
  }
  saveProduct(obj: any) {
    return this.http.post(this.baseUrl + '/api/Product/saveProduct', obj)
  }
  deleteProduct(obj: any) {
    return this.http.post(this.baseUrl + '/api/Product/deleteProduct', obj)
  }

  //Unit
  getUnitList(obj: any) {
    return this.http.post(this.baseUrl + '/api/Unit/UnitList', obj)
  }
  saveUnit(obj: any) {
    return this.http.post(this.baseUrl + '/api/Unit/saveUnit', obj)
  }
  deleteUnit(obj: any) {
    return this.http.post(this.baseUrl + '/api/Unit/deleteUnit', obj)
  }

  //Employee
  getEmployeeList(obj: any) {
    return this.http.post(this.baseUrl + '/api/Employee/EmployeeList', obj)
  }
  saveEmployee(obj: any) {
    return this.http.post(this.baseUrl + '/api/Employee/saveEmployee', obj)
  }
  deleteEmployee(obj: any) {
    return this.http.post(this.baseUrl + '/api/Employee/deleteEmployee', obj)
  }
  changePassword(obj: any) {
    return this.http.post(this.baseUrl + '/api/Employee/changePassword', obj)
  }
  employeeLogin(obj: any) {
    return this.http.post(this.baseUrl + '/api/Employee/EmployeeLogin', obj)
  }

  //Size
  getSizeList(obj: any) {
    return this.http.post(this.baseUrl + '/api/Size/SizeList', obj)
  }
  saveSize(obj: any) {
    return this.http.post(this.baseUrl + '/api/Size/saveSize', obj)
  }
  deleteSize(obj: any) {
    return this.http.post(this.baseUrl + '/api/Size/deleteSize', obj)
  }

  //Head
  getHeadList(obj: any) {
    return this.http.post(this.baseUrl + '/api/Head/HeadList', obj)
  }
  saveHead(obj: any) {
    return this.http.post(this.baseUrl + '/api/Head/saveHead', obj)
  }
  deleteHead(obj: any) {
    return this.http.post(this.baseUrl + '/api/Head/deleteHead', obj)
  }

  //Supplier
  getSupplierList(obj: any) {
    return this.http.post(this.baseUrl + '/api/Supplier/SupplierList', obj)
  }
  saveSupplier(obj: any) {
    return this.http.post(this.baseUrl + '/api/Supplier/saveSupplier', obj)
  }
  deleteSupplier(obj: any) {
    return this.http.post(this.baseUrl + '/api/Supplier/deleteSupplier', obj)
  }
}
