import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminMasterComponent } from './admin/admin-master/admin-master.component';
import { AdminDashboardComponent } from './admin/admin-dashboard/admin-dashboard.component';
import { PageNotFoundComponent } from './component/page-not-found/page-not-found.component';
import { CategoryComponent } from './admin/category/category.component';
import { SizeComponent } from './admin/size/size.component';
import { SupplierComponent } from './admin/supplier/supplier.component';
import { UnitComponent } from './admin/unit/unit.component';
import { EmployeeComponent } from './admin/employee/employee.component';
import { AdminLoginComponent } from './admin/admin-login/admin-login.component';
import { HeadComponent } from './admin/head/head.component';
import { ProductComponent } from './admin/product/product.component';
import { NewProductComponent } from './admin/new-product/new-product.component';
import { PurchaseComponent } from './admin/purchase/purchase.component';
import { PurchaseListComponent } from './admin/purchase-list/purchase-list.component';
import { ProductStockListComponent } from './admin/product-stock-list/product-stock-list.component';

const routes: Routes = [
  { path: '', redirectTo: "admin-login", pathMatch: 'full' },
  { path: 'admin-login', component: AdminLoginComponent },
  {
    path: 'admin', component: AdminMasterComponent, children: [
      { path: 'admin-dashboard', component: AdminDashboardComponent },
      { path: 'category', component: CategoryComponent },
      { path: 'size', component: SizeComponent },
      { path: 'supplier', component: SupplierComponent },
      { path: 'unit', component: UnitComponent },
      { path: 'employee', component: EmployeeComponent },
      { path: 'head', component: HeadComponent },
      { path: 'product', component: ProductComponent },
      { path: 'new-product', component: NewProductComponent },
      { path: 'purchase', component: PurchaseComponent },
      { path: 'purchase-list', component: PurchaseListComponent },
      { path: 'product-stock-list', component: ProductStockListComponent },
    ]
  },
  { path: '**', component: PageNotFoundComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {

}
