import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { HashLocationStrategy, LocationStrategy } from "@angular/common";
import { NgxPaginationModule } from "ngx-pagination";
import { OrderModule } from "ngx-order-pipe";
import { Ng2SearchPipeModule } from "ng2-search-filter";

import { AppRoutingModule } from './app-routing.module';
import { AppService } from "./utils/app.service";
import { AppComponent } from './app.component';
import { AdminMasterComponent } from './admin/admin-master/admin-master.component';
import { AdminDashboardComponent } from './admin/admin-dashboard/admin-dashboard.component';
import { PageNotFoundComponent } from './component/page-not-found/page-not-found.component';
import { CategoryComponent } from './admin/category/category.component';
import { SizeComponent } from './admin/size/size.component';
import { SupplierComponent } from './admin/supplier/supplier.component';
import { UnitComponent } from './admin/unit/unit.component';
import { EmployeeComponent } from './admin/employee/employee.component';
import { AdminLoginComponent } from './admin/admin-login/admin-login.component';
import { ProgressComponent } from './component/progress/progress.component';
import { HeadComponent } from './admin/head/head.component';
import { ProductComponent } from './admin/product/product.component';
import { NewProductComponent } from './admin/new-product/new-product.component';
import { PurchaseComponent } from './admin/purchase/purchase.component';
import { AutocompleteLibModule } from 'angular-ng-autocomplete';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { EditProductComponent } from './component/edit-product/edit-product.component';
import { PurchaseListComponent } from './admin/purchase-list/purchase-list.component';
import { ProductStockListComponent } from './admin/product-stock-list/product-stock-list.component';

@NgModule({
  declarations: [
    AppComponent,
    AdminMasterComponent,
    AdminDashboardComponent,
    PageNotFoundComponent,
    CategoryComponent,
    SizeComponent,
    SupplierComponent,
    UnitComponent,
    EmployeeComponent,
    AdminLoginComponent,
    ProgressComponent,
    HeadComponent,
    ProductComponent,
    NewProductComponent,
    PurchaseComponent,
    EditProductComponent,
    PurchaseListComponent,
    ProductStockListComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    NgxPaginationModule,
    OrderModule,
    Ng2SearchPipeModule,
    AutocompleteLibModule,
    BrowserAnimationsModule,
  ],
  providers: [AppService, { provide: LocationStrategy, useClass: HashLocationStrategy }],
  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AppModule { }
